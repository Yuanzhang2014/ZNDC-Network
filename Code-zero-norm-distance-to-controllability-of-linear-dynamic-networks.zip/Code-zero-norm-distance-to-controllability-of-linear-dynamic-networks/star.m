A=zeros(7,7);
A=-eye(7);
for i=2:7
A(i,1)=1;
end
for i=2:7
A(1,i)=1;
end
B=zeros(7,1);
B(1,1)=1;
Delta_initial=[A,B];
Delta_initial=double(Delta_initial~=0);