circle;
figure(1)
sequence_convex_nonsymmetric;
star;
figure(2)
sequence_convex_nonsymmetric;
chain;
figure(3)
sequence_convex_nonsymmetric;
circle;
% rank(ctrb(A,B))
% star;
% rank(ctrb(A,B))
% chain;
% rank(ctrb(A,B))

circle;
figure(1)
sequence_convex_symmetric;
theta_circle=theta_k;
star;
figure(2)
sequence_convex_symmetric;
theta_star=theta_k;
chain;
figure(3)
sequence_convex_symmetric;
theta_line=theta_k;


circle;
figure(1)
sequence_convex_symmetric_Laplacian;
theta_circle=theta_k;
obj_rec_circle=obj_rec;
star;
figure(2)
sequence_convex_symmetric_Laplacian;
theta_star=theta_k;
obj_rec_star=obj_rec;
chain;
figure(3)
sequence_convex_symmetric_Laplacian;
theta_line=theta_k;
obj_rec_line=obj_rec;