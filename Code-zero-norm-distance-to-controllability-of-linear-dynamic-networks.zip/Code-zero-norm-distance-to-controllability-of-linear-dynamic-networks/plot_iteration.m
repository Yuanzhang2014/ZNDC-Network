x1=length(obj_rec_circle);
plot(1:x1,obj_rec_circle,'-o');
hold on
x2=length(obj_rec_star);
plot(1:x2,obj_rec_star,'-s');
x3=length(obj_rec_line);
plot(1:x3,obj_rec_line,'-v');
xlabel('iteration')
ylabel('F(\theta^{(k)},W^{(k)},Z^{(k)})')
legend('circle','star','line')

x1=length(obj_rec_circle);
plot(1:x1,obj_rec_circle,'-.o');
hold on
x2=length(obj_rec_star);
plot(1:x2,obj_rec_star,'-.s');
x3=length(obj_rec_line);
plot(1:x3,obj_rec_line,'-.v');
xlabel('iteration')
ylabel('F(\theta^{(k)},W^{(k)},Z^{(k)})')
legend('circle','star','line')