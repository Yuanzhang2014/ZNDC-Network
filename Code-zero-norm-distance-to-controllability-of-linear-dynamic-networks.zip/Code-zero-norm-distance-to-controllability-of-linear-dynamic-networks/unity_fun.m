function y=unity_fun(A,B,Delta,gamma)
y=lambda_matroid_intersection_random(A,B,Delta)+gamma*findReachableGzvGzu(A,B,Delta);
