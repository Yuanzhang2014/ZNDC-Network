
function I=findReachableGzvGzu(A,B,Delta)
% given A, B and Delta
% find the number of reachable z vertices in G(Gzv,Gzu) 
[n,m]=size(B);
%syms s
[Gzv,Gzu]=findGzvGzu(A,B);
[m1,n1]=size([Gzv,Gzu]);
a=[Gzv,Gzu];
Delta_add=[Delta;zeros(m,m+n)];
% Expand out to symmetric (M+N)x(M+N) matrix
big_a = [zeros(m1,m1), a;
         Delta_add, zeros(n1,n1)];
%      I_u=zeros(m1+n1,1);
%      I_u(m+2*n+1:end)=1;
%      I_z=zeros(1,m1+n1);
%      I_z(1:m+n)=1;
% f=I_z*big_a^(m1+n1)*I_u;
Iz=[];
Iall=2*n+m+1:2*m+2*n;
zid=1:m+n;
for i=1:2*m+2*n
    sum_big_a=sum(big_a(:,Iall),2);
    Iall_new= find(sum_big_a>0);
    Iz=intersect(Iall_new,zid);
    Iall=[Iall_new;Iall];
    Iall=unique(Iall);
end
I=length(Iz);
