function y=unique_epsilon(l,epsilon)
n=length(l);
l=sort(l);
y=l(1);
for i=1:n
   if (l(i)-y(end))>epsilon
       y=[y,l(i)];
   end  
end
