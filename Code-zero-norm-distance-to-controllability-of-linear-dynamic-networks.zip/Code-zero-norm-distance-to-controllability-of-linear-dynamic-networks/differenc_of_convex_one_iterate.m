
A=ones(4,4);
B=[1;0;0;1];

r=5;
[n,m]=size(B);
Ar=double(rand(n*r,n)>0.8);
Br=double(rand(n*r,m)>0.9);


[n,m]=size(B);

tau=10^(-10);
eta=0.2;
gamma=10;
varplson=10^(-10);


%cof=1/tau*1/log(1+1/tau);
%Gamma=1./(1+1/tau*theta_k)*cof;

mubound=zeros(n,1);
for i=1:n
    mubound(i)=sum(abs(A(:,i)))+sum(abs(Ar(:,i)));
end
mu=max(mubound)+1;
    
%%% initial 
cvx_begin
variable  theta(r)
variable  W(n,n) symmetric;
variable  Z(3*n+m,3*n+m)
variable  W1(3*n+m,3*n+m) symmetric;
variable  W2(3*n+m,3*n+m) symmetric;

minimize(trace(W1+W2))
subject to
Atheta=kron(theta',eye(n))*Ar;
Btheta=kron(theta',eye(n))*Br;
M=[Atheta-mu*eye(n),W,Btheta];
N=[W,Atheta-mu*eye(n),Btheta]';
Z==[zeros(n),M;N,eye(2*n+m)];
W-varplson*eye(n) == semidefinite(n);
theta <= ones(r,1);
theta >= zeros(r,1);
ones(1,r)*theta>= 1-eta;
[W1,Z;Z',W2] == semidefinite(6*n+2*m);
cvx_end

% initial Z_k, theta_k
 Z_k=full(Z);
theta_k=theta;

[U,S,V] = svd(Z_k);
U_1=U(:,1:2*n+m);
V_1=V(:,1:2*n+m);
cof=1/tau*1/log(1+1/tau);
Gamma=1./(1+1/tau*theta_k)*cof;

%%%% first iterate


cvx_begin
variable  theta(r)
variable  W(n,n) symmetric;
variable  Z(3*n+m,3*n+m)
variable  W1(3*n+m,3*n+m) symmetric;
variable  W2(3*n+m,3*n+m) symmetric;

minimize((0.5*gamma*trace(W1+W2)+Gamma'*theta-gamma*trace(U_1'*Z*V_1)))
subject to
Atheta=kron(theta',eye(n))*Ar;
Btheta=kron(theta',eye(n))*Br;
M=[Atheta-mu*eye(n),W,Btheta];
N=[W,Atheta-mu*eye(n),Btheta]';
Z==[zeros(n),M;N,eye(2*n+m)];
W-varplson*eye(n) == semidefinite(n);
theta <= ones(r,1);
theta >= zeros(r,1);
ones(1,r)*theta>= 1-eta;
[W1,Z;Z',W2] == semidefinite(6*n+2*m);
cvx_end
