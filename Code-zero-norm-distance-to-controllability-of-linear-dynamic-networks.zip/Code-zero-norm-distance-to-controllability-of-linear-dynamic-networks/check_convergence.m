clear
n=6;
r=3;

I=eye(n);
% Pl=I(randi(n,2,1),:);
% 
% Pr=I(:,randi(n,1,2));
Pl=  [ 0     0     0     0     1     0
     0     0     0     0     0     1];
 Pr=[   0     0
     0     0
     1     0
     0     0
     0     0
     0     1];

Z_k=ones(n,n);

ite=0;
obj_new=1;
obj_old=0;
epsilon=10^(-15);
%while norm(theta_k-theta_old)/norm(theta_old)>epsilon
%while norm(theta_k-theta_old)>epsilon
while abs(obj_new-obj_old)>epsilon
   
    ite=ite+1;
    disp('the iteration')
    disp(ite);
    disp('obj-error')
    disp(obj_new-obj_old);
    
[U,S,V] = svd(Z_k);
U_1=U(:,1:r);
V_1=V(:,1:r);

L=rand(n)>0.7;
observe=randi(2,2)-1;
%%%% first iterate

cvx_begin quiet
variable  Z(n,n)
variable  W1(n,n) symmetric;
variable  W2(n,n) symmetric;

minimize(0.5*trace(W1+W2)-trace(U_1'*Z*V_1)+norm(Z))
subject to
[W1,Z;Z',W2] == semidefinite(2*n);
Pl*Z*Pr==observe;
cvx_end
%%%%%%%% new objective
S=svd(full(Z));
obj_new=sum(S)-sum(S(1:r));
%disp(obj_new)
%%%% update
Z_k=full(Z);
end
