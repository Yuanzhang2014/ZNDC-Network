
function Delta_greey=Greey_linkselection_random_right(A,B,Delta_intial)
% given A,B,Delta_intial
[n,m]=size(B);
gamma=1;
%unity_current=0;
unity_new=0;
Deltafull=ones(n,n+m);
unity_full=unity_fun(A,B,Deltafull,gamma);
Delta_current=zeros(n,n+m);
y_full=find(Delta_intial>0);
y_current=[];
unity_old=0;
while unity_new<unity_full
    unity_old=unity_new;
  %  y_current=find(Delta_current>0);
    y_cand=setdiff(y_full,y_current);
  %  unity_temp=0;
    y_chosen=y_current;
    unity_collect=zeros(length(y_cand),1);
    for ii=1:length(y_cand)
        Delta_temp=zeros(n,m+n);
        y_temp=[y_current;y_cand(ii)];
        Delta_temp(y_temp)=1;
        unity_newadd=unity_fun(A,B,Delta_temp,gamma);
        unity_collect(ii)=unity_newadd;
%         if unity_newadd>unity_temp
%             unity_temp=unity_newadd;
%             unity_new=unity_newadd;
%             y_chosen=y_temp;
%         end
    end
     unity_new=max(unity_collect);
  indmax= find(unity_collect==unity_new);
  
  ichosen=indmax(randi(length(indmax),1));
    y_chosen=[y_current;y_cand(ichosen)];
    y_current=y_chosen;
    Delta_current=zeros(n,n+m);
    Delta_current(y_current)=1;
    
  %  disp(y_current);
 %   disp(unity_new-unity_old);
   % disp(Delta_current);
end
Delta_greey=Delta_current;
