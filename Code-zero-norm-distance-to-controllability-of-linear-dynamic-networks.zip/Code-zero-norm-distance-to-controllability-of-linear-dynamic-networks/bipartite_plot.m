function bipartite_plot(a)
[m,n]=size(a);
% Expand out to symmetric (M+N)x(M+N) matrix
big_a = [zeros(m,m), a;
         zeros(n,m), zeros(n,n)]';     
g = digraph(big_a);
% Plot
h = plot(g);
% Make it pretty
h.XData(1:m) = 1;
h.XData((m+1):end) = 2;
h.YData(1:m) = linspace(0,1,m);
h.YData((m+1):end) = linspace(0,1,n);