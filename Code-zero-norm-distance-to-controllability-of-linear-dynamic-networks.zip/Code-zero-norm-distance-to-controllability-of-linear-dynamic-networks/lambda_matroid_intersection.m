
function S_cardi=lambda_matroid_intersection(A,B,Delta)
% given A,B
% Delta is the retangular matrix 
[n,m]=size(B);
E=1:2*n+m;
lambda=eig(A);
lambda=unique_epsilon(lambda,10^(-10)); % no repeated eigenvalues
r=length(lambda);
E=1:2*n+m;
S_cardi=0;
for i=1:r
    S1=[eye(n),lambda(i)*eye(n)-A,B];
    S2=[transpose(Delta),eye(n+m)];
    Si=MatroidIntersection(E,S1,S2);
    S_cardi=S_cardi+length(Si); % add the length
end

%%% wrong case to study:
% Delta=[     1     0     0     0     0     0     0
%      1     1     0     0     0     0     0
%      1     0     1     0     0     0     0
%      0     0     0     1     0     0     0
%      0     0     0     0     0     0     1
%      0     0     0     0     0     0     1];
%  A=[     1     1     1     1     1     1
%      1     1     1     1     1     1
%      1     1     1     1     1     1
%      1     1     1     1     1     1
%      1     1     1     1     1     1
%      1     1     1     1     1     1
% ];
% B=[ 1
%      1
%      1
%      1
%      1
%      1];
%  Wrong intersection answer. 
