
%n=6;
% A=double(rand(n,n)>0.8);
% B=double(rand(n,1)>0.8);

% n=6;
% A=ones(n);
% B=ones(n,1);
%  n=6;
%  A=zeros(n,n);
%  B=zeros(n,1);
 [n,m]=size(B);
 Delta_initial=ones(n,n+m);
%Delta_initial=double(rand(n,n+m)>0.4);
 
Delta_greey_random=Greey_linkselection_random_right(A,B,Delta_initial);
Delta=Delta_greey_random;
sum(sum(Delta))
%Delta=Delta_greey;
[t,s]=find(Delta>0);

AB=[[A B]+Delta*10;zeros(m,n+m)];%
%AB=[Delta_initial+Delta;zeros(m,n+m)];
AB=AB'
g=digraph(AB);
h=plot(g);
highlight(h,s,t,'EdgeColor','r','LineWidth',2)
set(gca,'visible','off')
% AB=[[A B]+Delta_greey;zeros(m,n+m)];
% AB=AB'
% g=digraph(AB);
% h=plot(g)