clear
A=ones(6,6);
B=[1;0;0;1;0;0];
format long

r=5;
[n,m]=size(B);
Ar=double(rand(n*r,n)>0.8);
Br=double(rand(n*r,m)>0.9);


[n,m]=size(B);

tau=10^(-5);
eta=0.1;
gamma=20;
varplson=10^(-10);
%varplson=0;
epsilon=10^(-3);
cof=1/tau*1/log(1+1/tau);


%cof=1/tau*1/log(1+1/tau);
%Gamma=1./(1+1/tau*theta_k)*cof;

mubound=zeros(n,1);
for i=1:n
    mubound(i)=sum(abs(A(:,i)))+sum(abs(Ar(:,i)));
end
mu=max(mubound)+1;
    
%%% initial 
cvx_begin quiet
variable  theta(r)
variable  W(n,n) symmetric;
variable  Z(3*n+m,3*n+m)
variable  W1(3*n+m,3*n+m) symmetric;
variable  W2(3*n+m,3*n+m) symmetric;

minimize(trace(W1+W2))
subject to
Atheta=kron(theta',eye(n))*Ar;
Btheta=kron(theta',eye(n))*Br;
M=[Atheta-mu*eye(n),W,Btheta];
N=[W,Atheta-mu*eye(n),Btheta]';
Z==[zeros(n),M;N,eye(2*n+m)];
W-varplson*eye(n) == semidefinite(n);
theta <= ones(r,1);
theta >= zeros(r,1);
ones(1,r)*theta>= 1-eta;
[W1,Z;Z',W2] == semidefinite(6*n+2*m);
cvx_end

% initial Z_k, theta_k

theta_old=ones(r,1);
theta_k=theta;
obj_old=1;
obj_new=cvx_optval;
Z_k=full(Z);

ite=0;

%while norm(theta_k-theta_old)/norm(theta_old)>epsilon
%while norm(theta_k-theta_old)>epsilon
while abs(obj_new-obj_old)>epsilon
   
    ite=ite+1;
    disp('the iteration')
    disp(ite);
    disp('error')
    disp(obj_new-obj_old);
    
    obj_old=obj_new;
theta_old=theta_k;

[U,S,V] = svd(Z_k);
U_1=U(:,1:2*n+m);
V_1=V(:,1:2*n+m);
Gamma=1./(1+1/tau*theta_k)*cof;

%%%% first iterate

cvx_begin quiet
variable  theta(r)
variable  W(n,n) symmetric;
variable  Z(3*n+m,3*n+m)
variable  W1(3*n+m,3*n+m) symmetric;
variable  W2(3*n+m,3*n+m) symmetric;

minimize((0.5*gamma*trace(W1+W2)+Gamma'*theta-gamma*trace(U_1'*Z*V_1)))
subject to
Atheta=kron(theta',eye(n))*Ar;
Btheta=kron(theta',eye(n))*Br;
M=[Atheta-mu*eye(n),W,Btheta];
N=[W,Atheta-mu*eye(n),Btheta]';
Z==[zeros(n),M;N,eye(2*n+m)];
W-varplson*eye(n) == semidefinite(n);
theta <= ones(r,1);
theta >= zeros(r,1);
ones(1,r)*theta>= 1-eta;
[W1,Z;Z',W2] == semidefinite(6*n+2*m);
cvx_end
%%%%%%%% new objective
theta_k=theta;
Z_k=full(Z);

obj_new=0;
for ii=1:r
    obj_new=obj_new+(1/log(1+1/tau))*log(1+theta_k(ii)/tau);
end
S=svd(full(Z));
obj_new=obj_new+gamma*(sum(S)-sum(S(1:2*n+m)));
%disp(obj_new)

%%%% update

end


%%%%%%%%%%%%%% check
theta=double(theta>0.5);
Aupdate=A+rand()*kron(theta',eye(n))*Ar
Bupdate=B+kron(theta',eye(n))*Br;
gram=ctrb(Aupdate,Bupdate);
disp(rank(gram))

