
function S_cardi=lambda_matroid_intersection_random(A,B,Delta)
% given A,B
% Delta is the retangular matrix 
[n,m]=size(B);
%E=1:2*n+m;
lambda=eig(A);
lambda=unique_epsilon(lambda,10^(-10)); % no repeated eigenvalues
r=length(lambda);
%E=1:2*n+m;
S_cardi=0;
for i=1:r
    S1=[eye(n),lambda(i)*eye(n)-A,B];
    S2=[transpose(Delta),eye(n+m)];
  %  Si=MatroidIntersection(E,S1,S2);
    Si=S1*(S2.*rand(n+m,2*n+m))';
    S_cardi=S_cardi+rank(Si); % add the length
end

