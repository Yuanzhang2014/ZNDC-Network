% n=5;
%  A=double(rand(n,n)>0.7);
%  B=double(rand(n,1)>0.8);

% n=6;
% A=ones(n);
% B=ones(n,1);

%  A=zeros(n,n);
%  B=zeros(n,1);

[n,m]=size(B);
%Delta_initial=ones(n,n+m);
Delta_initial=double([A,B]~=0);
% Delta_greey=Greey_linkselection(A,B,Delta_initial)
% sum(sum(Delta_greey))
% A1=A+Delta_greey(:,1:n).*rand(n,n);
% B1=B+Delta_greey(:,n+1:n+m).*rand(n,m);
% s=eig(A1);
% for i=1:n
% rank([s(i)*eye(n)-A1,B1])
% end


%rank(ctrb(A1,B))
Delta_greey_random=Greey_linkselection_random_right(A,B,Delta_initial)
sum(sum(Delta_greey_random))
% A1=A+Delta_greey(:,1:n).*rand(n,n);
% rank(ctrb(A1,B))
