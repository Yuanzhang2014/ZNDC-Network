

function [Gzv,Gzu]=findGzvGzu(A,B)
% given A, B
% construct the (Gzv, Gzu)
%syms s
[n,m]=size(B);
Gzv=zeros(n+m,n);
Gzu=zeros(n+m,m);
%s=1:2n;
In=1:n;
Im=1:m;
for i=1:n
    for j=1:n
        Gzv(i,j)=1;
        I=setdiff(In,j);
        J=setdiff(In,i);
        t=1;
        adj=t*eye(n)-A;
        while det(adj(I,J))==0 && t<n+2
              t=t+1;
              adj=t*eye(n)-A;
        end
        if t==n+2
            Gzv(i,j)=0;
        end
    end
end
%Gzu(n+1:n+m,1:m)=eye(m);

for i=1:n
    for j=1:m
        Gzu(i,j)=0;
        I=diff(In,j);
        J=diff(In,i);
        t=1;
        while t<n+2
        if det(t*eye(n)-A)~=0 
            w=inv(t*eye(n)-A)*B;
            if w(i,j)~=0
                 Gzu(i,j)=1;
                 break
            end
        end
        t=t+1;  
        end        
    end
end
 Gzu(n+1:n+m,1:m)=eye(m);


